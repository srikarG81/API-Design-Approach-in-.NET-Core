using System;

namespace Bookstore
{
    public class Bookshelves
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
